#include "_hnqx.h"

CSURFDATA::CSURFDATA(connection *conn,CLogFile *logfile)
{
	m_conn = conn;
	m_logfile = logfile;
}

CSURFDATA::~CSURFDATA()
{
}

bool CSURFDATA::SplitBuffer(const char *strBuffer)
{
	memset(&m_stsurfdata,0,sizeof(struct st_surfdata));

	CCmdStr CmdStr;

	CmdStr.SplitToCmd(strBuffer,",",true);

        if(CmdStr.CmdCount()!=9) return false;

        CmdStr.GetValue(0,m_stsurfdata.obtid,5);
        CmdStr.GetValue(1,m_stsurfdata.ddatetime,19);
        double demp = 0;
        CmdStr.GetValue(2,&demp);        m_stsurfdata.t = (int)(demp*10);
        CmdStr.GetValue(3,&demp);        m_stsurfdata.p = (int)(demp*10);
        CmdStr.GetValue(4,&m_stsurfdata.u);
        CmdStr.GetValue(5,&m_stsurfdata.wd);
        CmdStr.GetValue(6,&demp);        m_stsurfdata.wf = (int)(demp*10);
        CmdStr.GetValue(7,&demp);        m_stsurfdata.r = (int)(demp*10);
        CmdStr.GetValue(8,&demp);        m_stsurfdata.vis = (int)(demp*10);

	return true;
}

long CSURFDATA::InsertTable()
{
	if (stmtsel.m_state == 0)
	{
        	stmtsel.connect(m_conn);
	        stmtsel.prepare("select count(*) from T_SURFDATA where obtid = :1 and ddatetime = to_date(:2,'yyyy-mm-dd hh24:mi:ss')");
        	stmtsel.bindin(1,m_stsurfdata.obtid,5);
                stmtsel.bindin(2,m_stsurfdata.ddatetime,19);
       		stmtsel.bindout(1,&iccount);
	}

	if (stmtins.m_state == 0 )
	{
        	// SQL���Բ�����
        	stmtins.connect(m_conn);
	        //׼���������ݵ�SQL������Ҫ�жϷ���ֵ
        	stmtins.prepare("\
                insert into T_SURFDATA(OBTID,DDATETIME,T,P,U,WD,WF,R,VIS,CRTTIME,KEYID) \
                        values(:1,to_date(:2,'yyyy-mm-dd hh24:mi:ss'),:3,:4,:5,:6,:7,:8,:9,sysdate,SEQ_SURFDATA.NEXTVAL)");

        	//ΪSQL������������ĵ�ַ
        	stmtins.bindin(1,m_stsurfdata.obtid,5);
        	stmtins.bindin(2,m_stsurfdata.ddatetime,19);
        	stmtins.bindin(3,&m_stsurfdata.t);
        	stmtins.bindin(4,&m_stsurfdata.p);
        	stmtins.bindin(5,&m_stsurfdata.u);
        	stmtins.bindin(6,&m_stsurfdata.wd);
        	stmtins.bindin(7,&m_stsurfdata.wf);
        	stmtins.bindin(8,&m_stsurfdata.r);
        	stmtins.bindin(9,&m_stsurfdata.vis);
	}
	
	if(stmtsel.execute() != 0)
	{
		m_logfile->Write("stmtsel.execute() failed.\n%s\n%s\n",stmtsel.m_sql,stmtsel.m_cda.message);
		return stmtsel.m_cda.rc;
	}

	iccount = 0;
	stmtsel.next();
	if (iccount>0) return 0;

	// ÿ��ָ��������ֵ��ִ��SQL��䣬һ��Ҫ�жϷ���ֵ��0-�ɹ�������-ʧ�ܡ�
	if (stmtins.execute() != 0)
	{
		if (stmtins.m_cda.rc !=1)
		{
			m_logfile->Write("stmtins.execute() failed.\n%s\n%s\n",stmtins.m_sql,stmtins.m_cda.message);
			return stmtins.m_cda.rc;
		}
	}
	return 0;
}
